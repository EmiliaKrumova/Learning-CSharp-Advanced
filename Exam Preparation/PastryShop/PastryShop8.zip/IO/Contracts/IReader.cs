﻿namespace ChristmasPastryShop.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
