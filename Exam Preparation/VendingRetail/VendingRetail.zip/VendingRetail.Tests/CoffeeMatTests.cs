using NUnit.Framework;

namespace VendingRetail.Tests
{
    public class Tests
    {
        
        [SetUp]
        public void Setup()
        {
            CoffeeMat coffeeMat = new CoffeeMat(100, 10);
        }

        [Test]
        public void Test1()
        {
            Assert.Pass();
        }        
    }
}