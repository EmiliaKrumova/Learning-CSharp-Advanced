﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BankLoan.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
