﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace Vehicles
{
    public class Truck : Vehicle
    {
        public Truck(double fuelQuantity, double consumptionPerKM, double capacity) 
            : base(fuelQuantity, consumptionPerKM,capacity)
        {
            this.FuelQuantity = fuelQuantity;
            this.ConsumptionPerKM = consumptionPerKM + 1.6;
            this.Capacity = capacity;
        }

        public override string Drive(double km)
        {
            double neededFuelToDrive = km * this.ConsumptionPerKM;
            string stringToReturn = string.Empty;
            if (neededFuelToDrive <= FuelQuantity)
            {
                stringToReturn = $"Truck travelled {km} km";
                this.FuelQuantity -= neededFuelToDrive;
                //succes
                return stringToReturn;
            }
            else
            {
                stringToReturn = $"Truck needs refueling";
                return stringToReturn;

            }
        }

        public override void Refuel(double liters)
        {

            if(liters <= 0)
            {
                Console.WriteLine("Fuel must be a positive number");
                
            }
            else
            {
                if (this.FuelQuantity + liters * 0.95 > this.Capacity)
                {
                    Console.WriteLine($"Cannot fit {liters} fuel in the tank");
                }
                else
                {
                    FuelQuantity += liters;
                }
            }
           
        }

        public override string ToString()
        {
            return $"Truck: {this.FuelQuantity:f2}";
        }
    }
}
