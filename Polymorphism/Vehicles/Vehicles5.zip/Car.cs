﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicles
{
    public class Car : Vehicle, IVehicles
    {
        public Car(double fuelQuantity, double consumptionPerKM, double capacity) 
            : base(fuelQuantity, consumptionPerKM, capacity)
        {
            this.ConsumptionPerKM = consumptionPerKM + 0.9;
            this.FuelQuantity = fuelQuantity;
            this.Capacity = capacity;
            
        }

        public override string Drive(double km)
        {
            double neededFuelToDrive = km * this.ConsumptionPerKM;
            string stringToReturn = string.Empty;
            if(neededFuelToDrive<=FuelQuantity)
            {
                stringToReturn = $"Car travelled {km} km";
                this.FuelQuantity-= neededFuelToDrive;
                //succes
                return stringToReturn ;
            }
            else
            {
                stringToReturn = $"Car needs refueling";
                return stringToReturn ;

            }
        }

        public override void Refuel(double liters)
        {
            if (liters <= 0)
            {
                Console.WriteLine("Fuel must be a positive number");
            }
            else
            {
                if (this.FuelQuantity + liters > this.Capacity)
                {
                    Console.WriteLine($"Cannot fit {liters} fuel in the tank");
                }
                else
                {
                    FuelQuantity += liters;
                }
            }
        }

        public override string ToString()
        {
            return $"Car: {this.FuelQuantity:f2}";

        }
    }
}
