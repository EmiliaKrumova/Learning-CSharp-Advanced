﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicles
{
    public class Bus : Vehicle
    {
        public Bus(double fuelQuantity, double consumptionPerKM, double capacity) 
            : base(fuelQuantity, consumptionPerKM, capacity)
        {
            FuelQuantity = fuelQuantity;
            ConsumptionPerKM = consumptionPerKM;
            Capacity = capacity;
        }

        public override string Drive(double km)
        {
            ConsumptionPerKM += 1.4;
            double neededFuelToDrive = km * this.ConsumptionPerKM;
            string stringToReturn = string.Empty;
            if (neededFuelToDrive <= FuelQuantity)
            {
                stringToReturn = $"Bus travelled {km} km";
                this.FuelQuantity -= neededFuelToDrive;
                //succes
                return stringToReturn;
            }
            else
            {
                stringToReturn = $"Bus needs refueling";
                return stringToReturn;

            }
        }
        public string DriveEmpty(double km)
        {
            double neededFuelToDrive = km * this.ConsumptionPerKM;
            string stringToReturn = string.Empty;
            if (neededFuelToDrive <= FuelQuantity)
            {
                stringToReturn = $"Bus travelled {km} km";
                this.FuelQuantity -= neededFuelToDrive;
                //succes
                return stringToReturn;
            }
            else
            {
                stringToReturn = $"Bus needs refueling";
                return stringToReturn;

            }
        }

        public override void Refuel(double liters)
        {
            if (liters <= 0)
            {
                Console.WriteLine("Fuel must be a positive number");
            }
            else
            {
                if (this.FuelQuantity + liters  > this.Capacity)
                {
                    Console.WriteLine($"Cannot fit {liters} fuel in the tank");
                }
                else
                {
                    FuelQuantity += liters;
                }
            }
        }
        public override string ToString()
        {
            return $"Bus: {this.FuelQuantity:f2}";

        }
    }
}
