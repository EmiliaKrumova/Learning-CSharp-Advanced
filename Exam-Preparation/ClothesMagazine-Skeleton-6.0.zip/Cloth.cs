﻿namespace ClothesMagazine
{
    public class Cloth
    {
    }
}
