﻿namespace FootballTeam.Models
{
    public class Team
    {
        public Team(string name)
        {
            Name = name;
            Players = new List<Player>();
        }
        public string Name { get; set; }

        public List<Player> Players { get; set; }

        public double Rating => Math.Ceiling(Players.Average(p => p.Skills));

        public void AddPlayer(Player player) 
        {
            Players.Add(player);
        }

        public void RemovePlayer(string player)
        {
            var playerToREmove = Players.FirstOrDefault(p => p.Name == player);
            if (playerToREmove == null)
            {
                Console.WriteLine($"Player {player} is not in {Name} team.");
            }
            else 
            {
                Players.Remove(playerToREmove);
            }
        }
    }
}
