﻿namespace AutomotiveRepairShop
{
    public class RepairShop
    {
    }
}
