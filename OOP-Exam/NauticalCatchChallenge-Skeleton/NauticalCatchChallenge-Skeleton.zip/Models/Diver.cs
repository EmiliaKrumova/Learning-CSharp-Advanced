﻿using NauticalCatchChallenge.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NauticalCatchChallenge.Models
{
    public abstract class Diver : IDiver
    {
        private string name;
        private int oxygenLevel;
        private List<string> catched;
        //ctor
        public Diver(string name, int oxygenLevel)
        {
            this.Name = name;
            this.oxygenLevel = oxygenLevel;
            this.catched = new List<string>();
            
        }
        public string Name {get; private set;}

        public int OxygenLevel { get; protected set; }

        public IReadOnlyCollection<string> Catch => this.catched;

        public double CompetitionPoints => throw new NotImplementedException();

        public bool HasHealthIssues => throw new NotImplementedException();

        public void Hit(IFish fish)
        {
            throw new NotImplementedException();
        }

        public void Miss(int TimeToCatch)
        {
            throw new NotImplementedException();
        }

        public void RenewOxy()
        {
            throw new NotImplementedException();
        }

        public void UpdateHealthStatus()
        {
            throw new NotImplementedException();
        }
        public override string ToString()
        {
            return $"Diver [ Name: {this.Name}, Oxygen left: {this.OxygenLevel}, Fish caught: {this.Catch.Count}, Points earned: { this.CompetitionPoints} ]";
        }
    }
}
